package com.bit.opcode;

public class Bmi {

}
